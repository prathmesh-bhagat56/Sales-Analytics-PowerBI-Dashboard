(function () {
  "use strict";

  const DATA = window.SALES_DATA;
  if (!DATA) {
    console.error("SALES_DATA not loaded.");
    return;
  }

  const META = DATA.meta;
  const RAW = DATA.records; // [orderNo, orderDate, shipDate, custIdx, chIdx, currIdx, whIdx, regIdx, prodIdx, qty, unitPrice, unitCost, revenue, fulfillmentDays]

  // Format helpers
  const fmtCurrency = (v, decimals = 0) =>
    "$" + Number(v || 0).toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });

  const fmtCompact = (v) => {
    const abs = Math.abs(v);
    if (abs >= 1e6) return "$" + (v / 1e6).toFixed(2) + "M";
    if (abs >= 1e3) return "$" + (v / 1e3).toFixed(1) + "K";
    return "$" + v.toFixed(0);
  };

  const fmtInt = (v) => Number(v || 0).toLocaleString("en-US");
  const fmtPct = (v, d = 2) => Number(v || 0).toFixed(d) + "%";

  // Populate slicers
  const slicerYear = document.getElementById("slicerYear");
  const slicerChannel = document.getElementById("slicerChannel");
  const slicerCurrency = document.getElementById("slicerCurrency");
  const slicerWarehouse = document.getElementById("slicerWarehouse");
  const slicerCity = document.getElementById("slicerCity");
  const slicerProduct = document.getElementById("slicerProduct");

  META.channels.forEach((ch, idx) => {
    const opt = document.createElement("option");
    opt.value = String(idx);
    opt.textContent = ch;
    slicerChannel.appendChild(opt);
  });

  META.currencies.forEach((cur, idx) => {
    const opt = document.createElement("option");
    opt.value = String(idx);
    opt.textContent = cur;
    slicerCurrency.appendChild(opt);
  });

  META.warehouses.forEach((wh, idx) => {
    const opt = document.createElement("option");
    opt.value = String(idx);
    opt.textContent = wh;
    slicerWarehouse.appendChild(opt);
  });

  const citiesSet = new Set();
  Object.values(META.regions).forEach((r) => citiesSet.add(r.city));
  Array.from(citiesSet)
    .sort()
    .forEach((city) => {
      const opt = document.createElement("option");
      opt.value = city;
      opt.textContent = city;
      slicerCity.appendChild(opt);
    });

  Object.entries(META.products)
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .forEach(([idx, name]) => {
      const opt = document.createElement("option");
      opt.value = String(idx);
      opt.textContent = `${name} (ID ${idx})`;
      slicerProduct.appendChild(opt);
    });

  // Filter rows based on current slicers
  let filteredRows = [];

  function getFilteredRows() {
    const yr = slicerYear.value;
    const ch = slicerChannel.value;
    const cur = slicerCurrency.value;
    const wh = slicerWarehouse.value;
    const city = slicerCity.value;
    const prod = slicerProduct.value;

    return RAW.filter((r) => {
      if (yr !== "ALL" && r[1].slice(0, 4) !== yr) return false;
      if (ch !== "ALL" && String(r[4]) !== ch) return false;
      if (cur !== "ALL" && String(r[5]) !== cur) return false;
      if (wh !== "ALL" && String(r[6]) !== wh) return false;
      if (prod !== "ALL" && String(r[8]) !== prod) return false;
      if (city !== "ALL") {
        const reg = META.regions[r[7]];
        if (!reg || reg.city !== city) return false;
      }
      return true;
    });
  }

  // Main render trigger
  function updateDashboard() {
    filteredRows = getFilteredRows();
    const n = filteredRows.length;
    const pct = ((n / RAW.length) * 100).toFixed(1);
    document.getElementById("activeFilterBadge").textContent = `Showing ${fmtInt(n)} / ${fmtInt(RAW.length)} Orders (${pct}%)`;

    let totalRev = 0;
    let totalCogs = 0;
    let unitCostColSum = 0;
    let unitPriceSum = 0;
    let totalQty = 0;
    let totalFulfill = 0;
    let delayed10 = 0;

    const slaLimit = Number(document.getElementById("slaSlider").value || 10);

    for (let i = 0; i < n; i++) {
      const r = filteredRows[i];
      const qty = r[9];
      const uPrice = r[10];
      const uCost = r[11];
      const rev = r[12];
      const fDays = r[13];

      totalRev += rev;
      totalCogs += qty * uCost;
      unitCostColSum += uCost;
      unitPriceSum += uPrice;
      totalQty += qty;
      totalFulfill += fDays;
      if (fDays > slaLimit) delayed10++;
    }

    const totalProfit = totalRev - totalCogs;
    const marginPct = totalRev > 0 ? (totalProfit / totalRev) * 100 : 0;
    const avgPrice = n > 0 ? unitPriceSum / n : 0;
    const avgCost = n > 0 ? unitCostColSum / n : 0;
    const aov = n > 0 ? totalRev / n : 0;
    const avgFulfill = n > 0 ? totalFulfill / n : 0;
    const onTimeRate = n > 0 ? ((n - delayed10) / n) * 100 : 0;

    // Update KPI Cards
    document.getElementById("kpiTotalSales").textContent = fmtCompact(totalRev);
    document.getElementById("kpiExactSales").textContent = fmtCurrency(totalRev, 2);
    document.getElementById("kpiAovBadge").textContent = `AOV: ${fmtCompact(aov)}`;

    document.getElementById("kpiTotalProfit").textContent = fmtCompact(totalProfit);
    document.getElementById("kpiProfitExact").textContent = fmtCurrency(totalProfit, 2);
    document.getElementById("kpiMarginBadge").textContent = `${fmtPct(marginPct)} Margin`;

    document.getElementById("kpiAvgPrice").textContent = fmtCurrency(avgPrice, 2);
    document.getElementById("kpiAvgCost").textContent = `Avg Unit Cost: ${fmtCurrency(avgCost, 2)}`;
    document.getElementById("kpiUnitSpread").textContent = `+${fmtCurrency(avgPrice - avgCost, 2)}/unit`;

    document.getElementById("kpiTotalCogs").textContent = fmtCompact(totalCogs);
    document.getElementById("kpiUnitCostSum").textContent = `Unit Cost Sum: ${fmtCompact(unitCostColSum)}`;

    document.getElementById("kpiTotalOrders").textContent = fmtInt(n);
    document.getElementById("kpiTotalQty").textContent = `${fmtInt(totalQty)} Units Sold`;
    document.getElementById("kpiAvgQty").textContent = `${n > 0 ? (totalQty / n).toFixed(2) : "0.00"} Units/Order`;

    document.getElementById("kpiAvgFulfill").textContent = `${avgFulfill.toFixed(2)} Days`;
    document.getElementById("kpiOnTimeRate").textContent = `On-Time (≤${slaLimit}d): ${onTimeRate.toFixed(1)}%`;
    document.getElementById("kpiDelayedCount").textContent = `${fmtInt(delayed10)} >${slaLimit}d`;

    renderOverviewTab(filteredRows, totalRev, totalProfit, marginPct, avgFulfill);
    renderChannelsCurrencyTab(filteredRows, totalRev);
    renderCustomersProductsTab(filteredRows, totalRev);
    renderWarehouseRegionalTab(filteredRows, totalRev, slaLimit);
    renderProfitabilityTab(filteredRows, totalRev);
  }

  // TAB 1: Overview & Sales Trends
  function renderOverviewTab(rows, totalRev, totalProfit, marginPct, avgFulfill) {
    const ymMap = {};
    const monthSeason = Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      name: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][i],
      rev: 0,
      profit: 0,
      orders: 0
    }));
    const yrMap = {};

    rows.forEach((r) => {
      const ym = r[1].slice(0, 7);
      const yr = r[1].slice(0, 4);
      const mIdx = parseInt(r[1].slice(5, 7), 10) - 1;
      const rev = r[12];
      const cogs = r[9] * r[11];
      const prof = rev - cogs;

      if (!ymMap[ym]) ymMap[ym] = { ym, rev: 0, profit: 0, orders: 0 };
      ymMap[ym].rev += rev;
      ymMap[ym].profit += prof;
      ymMap[ym].orders += 1;

      monthSeason[mIdx].rev += rev;
      monthSeason[mIdx].profit += prof;
      monthSeason[mIdx].orders += 1;

      if (!yrMap[yr]) yrMap[yr] = { yr, orders: 0, qty: 0, rev: 0, cogs: 0, profit: 0, fulfill: 0 };
      yrMap[yr].orders += 1;
      yrMap[yr].qty += r[9];
      yrMap[yr].rev += rev;
      yrMap[yr].cogs += cogs;
      yrMap[yr].profit += prof;
      yrMap[yr].fulfill += r[13];
    });

    const ymSeries = Object.values(ymMap).sort((a, b) => a.ym.localeCompare(b.ym));
    const metricMode = document.getElementById("trendMetricSelect").value;
    const trendEl = document.getElementById("monthlyTrendChart");

    if (ymSeries.length === 0) {
      trendEl.innerHTML = `<div style="padding:40px;text-align:center;color:#64748b;">No orders match current filters.</div>`;
    } else {
      const W = 820, H = 250, padL = 58, padR = 20, padT = 20, padB = 42;
      const plotW = W - padL - padR;
      const plotH = H - padT - padB;
      const maxVal = Math.max(...ymSeries.map((d) => (metricMode === "orders" ? d.orders : d.rev)), 1);

      const xPos = (i) => padL + (ymSeries.length === 1 ? plotW / 2 : (i / (ymSeries.length - 1)) * plotW);
      const yPos = (v) => padT + plotH - (v / maxVal) * plotH;

      let polyRev = ymSeries.map((d, i) => `${xPos(i).toFixed(1)},${yPos(metricMode === "orders" ? d.orders : d.rev).toFixed(1)}`).join(" ");
      let areaRev = `${xPos(0).toFixed(1)},${padT + plotH} ${polyRev} ${xPos(ymSeries.length - 1).toFixed(1)},${padT + plotH}`;
      let polyProf = ymSeries.map((d, i) => `${xPos(i).toFixed(1)},${yPos(d.profit).toFixed(1)}`).join(" ");

      let gridLines = "";
      for (let g = 0; g <= 4; g++) {
        const gv = (maxVal / 4) * g;
        const gy = yPos(gv);
        const label = metricMode === "orders" ? Math.round(gv) : fmtCompact(gv);
        gridLines += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="#e2e8f0" stroke-dasharray="3,3" />
                      <text x="${padL - 6}" y="${gy + 4}" text-anchor="end" font-size="10" fill="#64748b">${label}</text>`;
      }

      let xLabels = "";
      const step = Math.max(1, Math.floor(ymSeries.length / 9));
      ymSeries.forEach((d, i) => {
        if (i % step === 0 || i === ymSeries.length - 1) {
          xLabels += `<text x="${xPos(i)}" y="${H - 14}" text-anchor="middle" font-size="10" fill="#475569">${d.ym}</text>`;
        }
      });

      let dots = ymSeries
        .map((d, i) => {
          const val = metricMode === "orders" ? d.orders : d.rev;
          const title = `${d.ym}: Sales ${fmtCurrency(d.rev, 0)} | Profit ${fmtCurrency(d.profit, 0)} | Orders ${d.orders}`;
          return `<circle cx="${xPos(i)}" cy="${yPos(val)}" r="3.5" fill="#2563eb"><title>${title}</title></circle>`;
        })
        .join("");

      trendEl.innerHTML = `
        <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:100%;">
          ${gridLines}
          <polygon points="${areaRev}" fill="rgba(37,99,235,0.10)" />
          <polyline fill="none" stroke="#2563eb" stroke-width="2.4" points="${polyRev}" />
          ${
            metricMode === "revenue"
              ? `<polyline fill="none" stroke="#059669" stroke-width="2" stroke-dasharray="4,3" points="${polyProf}" />`
              : ""
          }
          ${dots}
          ${xLabels}
          <g transform="translate(${padL + 10}, 12)">
            <rect x="0" y="-8" width="10" height="10" fill="#2563eb" rx="2"/>
            <text x="14" y="0" font-size="11" fill="#1e293b" font-weight="600">${metricMode === "orders" ? "Monthly Orders" : "Monthly Sales ($)"}</text>
            ${
              metricMode === "revenue"
                ? `<rect x="135" y="-8" width="10" height="10" fill="#059669" rx="2"/><text x="149" y="0" font-size="11" fill="#1e293b" font-weight="600">Gross Profit ($)</text>`
                : ""
            }
          </g>
        </svg>`;
    }

    // Seasonality Bars
    const maxSeasonRev = Math.max(...monthSeason.map((m) => m.rev), 1);
    document.getElementById("seasonalityChart").innerHTML = monthSeason
      .map((m) => {
        const wPct = ((m.rev / maxSeasonRev) * 100).toFixed(1);
        const isPeak = m.rev === maxSeasonRev && m.rev > 0;
        return `
        <div class="bar-row" style="margin-bottom:4px;">
          <div class="bar-label" style="width:42px;font-weight:${isPeak ? "700" : "500"};">${m.name}</div>
          <div class="bar-track" style="height:14px;">
            <div class="bar-fill" style="width:${wPct}%;background:${isPeak ? "#059669" : "#2563eb"};"></div>
          </div>
          <div class="bar-val" style="width:125px;font-size:11.5px;">${fmtCompact(m.rev)} <span style="color:#64748b;font-weight:400;">(${m.orders})</span></div>
        </div>`;
      })
      .join("");

    // Yearly Summary Table
    const yrs = Object.values(yrMap).sort((a, b) => a.yr.localeCompare(b.yr));
    document.getElementById("yearlySummaryTable").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Year</th>
            <th class="num">Orders</th>
            <th class="num">Units Sold</th>
            <th class="num">Total Sales</th>
            <th class="num">Total COGS</th>
            <th class="num">Gross Profit</th>
            <th class="num">Margin %</th>
            <th class="num">Avg Fulfill</th>
          </tr>
        </thead>
        <tbody>
          ${yrs
            .map((y) => {
              const m = y.rev > 0 ? (y.profit / y.rev) * 100 : 0;
              const f = y.orders > 0 ? y.fulfill / y.orders : 0;
              return `<tr>
                <td><strong>${y.yr}</strong>${y.yr === "2019" ? ' <span style="color:#64748b;font-size:11px;">(thru Dec 12)</span>' : ""}</td>
                <td class="num">${fmtInt(y.orders)}</td>
                <td class="num">${fmtInt(y.qty)}</td>
                <td class="num"><strong>${fmtCurrency(y.rev, 2)}</strong></td>
                <td class="num">${fmtCurrency(y.cogs, 2)}</td>
                <td class="num" style="color:#059669;font-weight:600;">${fmtCurrency(y.profit, 2)}</td>
                <td class="num">${fmtPct(m)}</td>
                <td class="num">${f.toFixed(2)} d</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;

    // Executive Summary Narrative
    const topYm = ymSeries.slice().sort((a, b) => b.rev - a.rev)[0];
    document.getElementById("overviewNarrative").innerHTML = `
      <div style="padding:8px 10px;background:#f8fafc;border-left:3px solid #2563eb;border-radius:4px;">
        <strong>1. Revenue &amp; Profitability Scale:</strong> Selected segment generated <strong>${fmtCurrency(totalRev, 2)}</strong> in revenue and <strong>${fmtCurrency(totalProfit, 2)}</strong> in gross profit (<strong>${fmtPct(marginPct)}</strong> margin) across <strong>${fmtInt(rows.length)}</strong> orders.
      </div>
      <div style="padding:8px 10px;background:#f8fafc;border-left:3px solid #059669;border-radius:4px;">
        <strong>2. Peak Period &amp; Seasonality:</strong> Highest monthly revenue occurred in <strong>${topYm ? topYm.ym : "N/A"}</strong> (<strong>${topYm ? fmtCurrency(topYm.rev, 2) : "$0"}</strong>). Calendar seasonality peaks in <strong>March</strong> and <strong>August–October</strong>.
      </div>
      <div style="padding:8px 10px;background:#f8fafc;border-left:3px solid #d97706;border-radius:4px;">
        <strong>3. Warehouse &amp; SLA Lead Time:</strong> Average order fulfillment time is <strong>${avgFulfill.toFixed(2)} days</strong> (range 3–18 days). Note that 2019 orders run through <strong>Dec 12, 2019</strong>.
      </div>
    `;
  }

  // TAB 2: Channels & Currency Impact
  function renderChannelsCurrencyTab(rows, totalRev) {
    const chStats = META.channels.map((name, idx) => ({ idx, name, orders: 0, qty: 0, rev: 0, cogs: 0, profit: 0, fulfill: 0 }));
    const curStats = META.currencies.map((name, idx) => ({ idx, name, orders: 0, qty: 0, rev: 0, cogs: 0, profit: 0 }));
    const matrix = {};

    rows.forEach((r) => {
      const chIdx = r[4];
      const curIdx = r[5];
      const qty = r[9];
      const rev = r[12];
      const cogs = qty * r[11];
      const prof = rev - cogs;

      chStats[chIdx].orders += 1;
      chStats[chIdx].qty += qty;
      chStats[chIdx].rev += rev;
      chStats[chIdx].cogs += cogs;
      chStats[chIdx].profit += prof;
      chStats[chIdx].fulfill += r[13];

      curStats[curIdx].orders += 1;
      curStats[curIdx].qty += qty;
      curStats[curIdx].rev += rev;
      curStats[curIdx].cogs += cogs;
      curStats[curIdx].profit += prof;

      const key = `${chIdx}_${curIdx}`;
      if (!matrix[key]) matrix[key] = { rev: 0, orders: 0, profit: 0 };
      matrix[key].rev += rev;
      matrix[key].orders += 1;
      matrix[key].profit += prof;
    });

    const chColors = ["#2563eb", "#0d9488", "#7c3aed"];
    const sortedCh = chStats.slice().sort((a, b) => b.rev - a.rev);

    document.getElementById("channelVisualContainer").innerHTML = `
      <div style="margin-bottom:12px;">
        ${sortedCh
          .map((c, i) => {
            const share = totalRev > 0 ? (c.rev / totalRev) * 100 : 0;
            const margin = c.rev > 0 ? (c.profit / c.rev) * 100 : 0;
            return `
            <div style="margin-bottom:10px;">
              <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;">
                <span><strong>${c.name}</strong> (${fmtInt(c.orders)} orders &bull; ${fmtPct(share, 1)} share)</span>
                <span><strong>${fmtCurrency(c.rev, 2)}</strong> &bull; <span style="color:#059669;font-weight:600;">${fmtPct(margin)} Margin</span></span>
              </div>
              <div class="bar-track" style="height:18px;">
                <div class="bar-fill" style="width:${share.toFixed(1)}%;background:${chColors[i % chColors.length]};"></div>
              </div>
            </div>`;
          })
          .join("")}
      </div>
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Channel</th>
            <th class="num">Orders</th>
            <th class="num">Units</th>
            <th class="num">Revenue</th>
            <th class="num">Share %</th>
            <th class="num">Profit</th>
            <th class="num">Margin %</th>
          </tr>
        </thead>
        <tbody>
          ${sortedCh
            .map((c) => {
              const share = totalRev > 0 ? (c.rev / totalRev) * 100 : 0;
              const margin = c.rev > 0 ? (c.profit / c.rev) * 100 : 0;
              return `<tr>
                <td><strong>${c.name}</strong></td>
                <td class="num">${fmtInt(c.orders)}</td>
                <td class="num">${fmtInt(c.qty)}</td>
                <td class="num"><strong>${fmtCurrency(c.rev, 2)}</strong></td>
                <td class="num">${fmtPct(share)}</td>
                <td class="num" style="color:#059669;">${fmtCurrency(c.profit, 2)}</td>
                <td class="num"><span class="status-pill status-good">${fmtPct(margin)}</span></td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;

    // FX Multipliers
    const fxMultipliers = {
      NZD: parseFloat(document.getElementById("fxNZD").value || "1"),
      USD: parseFloat(document.getElementById("fxUSD").value || "1"),
      AUD: parseFloat(document.getElementById("fxAUD").value || "1"),
      EUR: parseFloat(document.getElementById("fxEUR").value || "1"),
      GBP: parseFloat(document.getElementById("fxEUR").value || "1")
    };
    document.getElementById("fxValNZD").textContent = fxMultipliers.NZD.toFixed(2);
    document.getElementById("fxValUSD").textContent = fxMultipliers.USD.toFixed(2);
    document.getElementById("fxValAUD").textContent = fxMultipliers.AUD.toFixed(2);
    document.getElementById("fxValEUR").textContent = fxMultipliers.EUR.toFixed(2);

    let totalFxAdjusted = 0;
    const sortedCur = curStats.slice().sort((a, b) => b.rev - a.rev);
    sortedCur.forEach((c) => {
      c.fxRev = c.rev * (fxMultipliers[c.name] || 1);
      totalFxAdjusted += c.fxRev;
    });

    const fxDelta = totalFxAdjusted - totalRev;
    const fxDeltaSign = fxDelta >= 0 ? "+" : "";
    document.getElementById("fxSimulationBanner").textContent = `FX-Adjusted Total Revenue: ${fmtCurrency(totalFxAdjusted, 2)} (${fxDeltaSign}${fmtCurrency(fxDelta, 2)} vs. Nominal)`;

    document.getElementById("currencyTableContainer").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Currency</th>
            <th class="num">Orders</th>
            <th class="num">Nominal Revenue</th>
            <th class="num">Share %</th>
            <th class="num">FX Multiplier</th>
            <th class="num">FX-Adjusted Rev</th>
            <th class="num">Margin %</th>
          </tr>
        </thead>
        <tbody>
          ${sortedCur
            .map((c) => {
              const share = totalRev > 0 ? (c.rev / totalRev) * 100 : 0;
              const margin = c.rev > 0 ? (c.profit / c.rev) * 100 : 0;
              const mult = fxMultipliers[c.name] || 1;
              return `<tr>
                <td><strong>${c.name}</strong></td>
                <td class="num">${fmtInt(c.orders)}</td>
                <td class="num">${fmtCurrency(c.rev, 2)}</td>
                <td class="num">${fmtPct(share)}</td>
                <td class="num">${mult.toFixed(2)}x</td>
                <td class="num"><strong>${fmtCurrency(c.fxRev, 2)}</strong></td>
                <td class="num">${fmtPct(margin)}</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;

    // Cross-Tab Matrix
    document.getElementById("channelCurrencyMatrix").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Channel \\ Currency</th>
            ${META.currencies.map((cur) => `<th class="num">${cur}</th>`).join("")}
            <th class="num">Total Channel Sales</th>
          </tr>
        </thead>
        <tbody>
          ${META.channels
            .map((chName, chIdx) => {
              let rowSum = 0;
              const cells = META.currencies
                .map((_, curIdx) => {
                  const cell = matrix[`${chIdx}_${curIdx}`] || { rev: 0, orders: 0 };
                  rowSum += cell.rev;
                  return `<td class="num">${fmtCompact(cell.rev)} <span style="color:#64748b;font-size:11px;">(${cell.orders})</span></td>`;
                })
                .join("");
              return `<tr>
                <td><strong>${chName}</strong></td>
                ${cells}
                <td class="num"><strong>${fmtCurrency(rowSum, 2)}</strong></td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;
  }

  // TAB 3: Customers & Product Performance
  function renderCustomersProductsTab(rows, totalRev) {
    const custMap = {};
    Object.entries(META.customers).forEach(([idx, name]) => {
      custMap[idx] = { idx: Number(idx), name, orders: 0, qty: 0, rev: 0, cogs: 0, profit: 0 };
    });

    const prodMap = {};
    Object.entries(META.products).forEach(([idx, name]) => {
      prodMap[idx] = { idx: Number(idx), name, orders: 0, qty: 0, rev: 0, cogs: 0, profit: 0, byChannel: [0, 0, 0] };
    });

    rows.forEach((r) => {
      const c = custMap[r[3]];
      const p = prodMap[r[8]];
      const qty = r[9];
      const rev = r[12];
      const cogs = qty * r[11];
      const prof = rev - cogs;

      if (c) {
        c.orders += 1;
        c.qty += qty;
        c.rev += rev;
        c.cogs += cogs;
        c.profit += prof;
      }
      if (p) {
        p.orders += 1;
        p.qty += qty;
        p.rev += rev;
        p.cogs += cogs;
        p.profit += prof;
        p.byChannel[r[4]] += rev;
      }
    });

    const custList = Object.values(custMap).sort((a, b) => b.rev - a.rev);
    const activeCusts = custList.filter((c) => c.orders > 0);

    // Customer Scatter SVG
    const W = 640, H = 245, padL = 55, padR = 20, padT = 18, padB = 34;
    const plotW = W - padL - padR;
    const plotH = H - padT - padB;
    const minOrd = Math.min(...activeCusts.map((c) => c.orders), 0);
    const maxOrd = Math.max(...activeCusts.map((c) => c.orders), 10);
    const maxRev = Math.max(...activeCusts.map((c) => c.rev), 1000);
    const avgOrd = activeCusts.length ? activeCusts.reduce((s, c) => s + c.orders, 0) / activeCusts.length : 0;
    const avgRev = activeCusts.length ? activeCusts.reduce((s, c) => s + c.rev, 0) / activeCusts.length : 0;

    const xP = (o) => padL + ((o - minOrd * 0.9) / Math.max(1, maxOrd * 1.05 - minOrd * 0.9)) * plotW;
    const yP = (rv) => padT + plotH - (rv / (maxRev * 1.08)) * plotH;

    const circles = activeCusts
      .map((c, i) => {
        const isTop5 = i < 5;
        return `<circle cx="${xP(c.orders).toFixed(1)}" cy="${yP(c.rev).toFixed(1)}" r="${isTop5 ? 6 : 4.2}" fill="${
          isTop5 ? "#059669" : "#2563eb"
        }" fill-opacity="0.82" stroke="#fff" stroke-width="1">
          <title>${c.name}: ${fmtCurrency(c.rev, 0)} (${c.orders} orders, Profit ${fmtCurrency(c.profit, 0)})</title>
        </circle>
        ${
          i < 3
            ? `<text x="${xP(c.orders) - 6}" y="${yP(c.rev) - 8}" font-size="10" font-weight="600" fill="#0f172a" text-anchor="end">${c.name}</text>`
            : ""
        }`;
      })
      .join("");

    document.getElementById("customerScatterChart").innerHTML = `
      <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:100%;">
        <rect x="${padL}" y="${padT}" width="${plotW}" height="${plotH}" fill="#f8fafc" stroke="#e2e8f0" />
        <line x1="${xP(avgOrd)}" y1="${padT}" x2="${xP(avgOrd)}" y2="${padT + plotH}" stroke="#94a3b8" stroke-dasharray="4,4" />
        <line x1="${padL}" y1="${yP(avgRev)}" x2="${padL + plotW}" y2="${yP(avgRev)}" stroke="#94a3b8" stroke-dasharray="4,4" />
        <text x="${padL + 6}" y="${yP(avgRev) - 5}" font-size="10" fill="#64748b">Avg Sales: ${fmtCompact(avgRev)}</text>
        <text x="${xP(avgOrd) + 5}" y="${padT + 12}" font-size="10" fill="#64748b">Avg Orders: ${avgOrd.toFixed(1)}</text>
        ${circles}
        <text x="${padL + plotW / 2}" y="${H - 6}" text-anchor="middle" font-size="11" fill="#475569" font-weight="600">Number of Orders per Customer &rarr;</text>
        <text x="14" y="${padT + plotH / 2}" transform="rotate(-90 14,${padT + plotH / 2})" text-anchor="middle" font-size="11" fill="#475569" font-weight="600">Total Sales ($)</text>
      </svg>`;

    document.getElementById("customerTableContainer").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Customer Name</th>
            <th class="num">Orders</th>
            <th class="num">Units</th>
            <th class="num">Total Sales</th>
            <th class="num">Gross Profit</th>
            <th class="num">Margin %</th>
          </tr>
        </thead>
        <tbody>
          ${custList
            .map((c, idx) => {
              const m = c.rev > 0 ? (c.profit / c.rev) * 100 : 0;
              return `<tr>
                <td>#${idx + 1}</td>
                <td><strong>${c.name}</strong></td>
                <td class="num">${fmtInt(c.orders)}</td>
                <td class="num">${fmtInt(c.qty)}</td>
                <td class="num"><strong>${fmtCurrency(c.rev, 2)}</strong></td>
                <td class="num" style="color:#059669;">${fmtCurrency(c.profit, 2)}</td>
                <td class="num">${fmtPct(m)}</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;

    // Products Bar List (including Product 20 with 0 orders!)
    const prodList = Object.values(prodMap).sort((a, b) => b.rev - a.rev);
    const maxProdRev = Math.max(...prodList.map((p) => p.rev), 1);

    document.getElementById("productBarsContainer").innerHTML = prodList
      .map((p, idx) => {
        const wPct = ((p.rev / maxProdRev) * 100).toFixed(1);
        const share = totalRev > 0 ? (p.rev / totalRev) * 100 : 0;
        const margin = p.rev > 0 ? (p.profit / p.rev) * 100 : 0;
        const isDormant = p.orders === 0;
        return `
        <div class="bar-row" style="margin-bottom:7px;">
          <div class="bar-label" style="width:110px;">
            <strong>${p.name}</strong>
            ${isDormant ? '<span class="status-pill status-bad" style="margin-left:4px;">0 Orders</span>' : `<span style="color:#64748b;font-size:11px;">(#${idx + 1})</span>`}
          </div>
          <div class="bar-track" style="height:16px;">
            <div class="bar-fill" style="width:${wPct}%;background:${isDormant ? "#ef4444" : idx < 7 ? "#2563eb" : "#0d9488"};"></div>
          </div>
          <div class="bar-val" style="width:190px;font-size:11.5px;">
            ${isDormant ? '<span style="color:#e11d48;">$0 (Dormant SKU)</span>' : `${fmtCompact(p.rev)} <span style="color:#64748b;">(${fmtPct(share, 1)} | ${fmtPct(margin, 1)} mgn)</span>`}
          </div>
        </div>`;
      })
      .join("");

    // Product x Channel Heatmap
    let maxCellRev = 1;
    prodList.forEach((p) => p.byChannel.forEach((v) => { if (v > maxCellRev) maxCellRev = v; }));

    document.getElementById("productChannelHeatmap").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th class="num">Orders</th>
            ${META.channels.map((ch) => `<th class="num">${ch}</th>`).join("")}
            <th class="num">Total Product Sales</th>
            <th class="num">Share %</th>
            <th class="num">Status</th>
          </tr>
        </thead>
        <tbody>
          ${prodList
            .map((p) => {
              const share = totalRev > 0 ? (p.rev / totalRev) * 100 : 0;
              const cells = p.byChannel
                .map((val) => {
                  const alpha = (val / maxCellRev) * 0.45;
                  return `<td class="num" style="background:rgba(37,99,235,${alpha.toFixed(2)});font-weight:${alpha > 0.2 ? "600" : "400"};">${fmtCurrency(val, 0)}</td>`;
                })
                .join("");
              return `<tr>
                <td><strong>${p.name}</strong></td>
                <td class="num">${fmtInt(p.orders)}</td>
                ${cells}
                <td class="num"><strong>${fmtCurrency(p.rev, 2)}</strong></td>
                <td class="num">${fmtPct(share)}</td>
                <td class="num">${
                  p.orders === 0
                    ? '<span class="status-pill status-bad">Dormant SKU</span>'
                    : share > 10
                    ? '<span class="status-pill status-good">Core Pareto SKU</span>'
                    : '<span class="status-pill status-warn">Tail SKU</span>'
                }</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;
  }

  // TAB 4: Warehouse & Regional Analytics
  function renderWarehouseRegionalTab(rows, totalRev, slaLimit) {
    document.getElementById("slaDaysLabel").textContent = String(slaLimit);

    const whStats = META.warehouses.map((name, idx) => ({
      idx,
      name,
      orders: 0,
      qty: 0,
      rev: 0,
      profit: 0,
      fulfillSum: 0,
      onTime: 0,
      delayed: 0
    }));

    const dayHist = {};
    for (let d = 3; d <= 18; d++) dayHist[d] = 0;

    const regStats = {};
    const cityStats = {};

    rows.forEach((r) => {
      const w = whStats[r[6]];
      const fDays = r[13];
      const rev = r[12];
      const prof = rev - r[9] * r[11];

      w.orders += 1;
      w.qty += r[9];
      w.rev += rev;
      w.profit += prof;
      w.fulfillSum += fDays;
      if (fDays <= slaLimit) w.onTime += 1;
      else w.delayed += 1;

      dayHist[fDays] = (dayHist[fDays] || 0) + 1;

      const regIdx = r[7];
      const regMeta = META.regions[regIdx];
      if (regMeta) {
        if (!regStats[regIdx]) {
          regStats[regIdx] = { ...regMeta, idx: regIdx, orders: 0, rev: 0, profit: 0, fulfillSum: 0 };
        }
        regStats[regIdx].orders += 1;
        regStats[regIdx].rev += rev;
        regStats[regIdx].profit += prof;
        regStats[regIdx].fulfillSum += fDays;

        const cName = regMeta.city;
        if (!cityStats[cName]) cityStats[cName] = { city: cName, orders: 0, qty: 0, rev: 0, profit: 0, fulfillSum: 0 };
        cityStats[cName].orders += 1;
        cityStats[cName].qty += r[9];
        cityStats[cName].rev += rev;
        cityStats[cName].profit += prof;
        cityStats[cName].fulfillSum += fDays;
      }
    });

    const totalOnTime = whStats.reduce((s, w) => s + w.onTime, 0);
    const totalOnTimePct = rows.length > 0 ? (totalOnTime / rows.length) * 100 : 0;
    const pill = document.getElementById("slaSummaryPill");
    pill.textContent = `${totalOnTimePct.toFixed(1)}% On-Time (≤${slaLimit}d)`;
    pill.className = `status-pill ${totalOnTimePct >= 60 ? "status-good" : totalOnTimePct >= 45 ? "status-warn" : "status-bad"}`;

    const sortedWh = whStats.slice().sort((a, b) => b.orders - a.orders);
    document.getElementById("warehouseTableContainer").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Warehouse Code</th>
            <th class="num">Orders</th>
            <th class="num">Volume Share</th>
            <th class="num">Revenue</th>
            <th class="num">Avg Days</th>
            <th class="num">On-Time (&le;${slaLimit}d)</th>
            <th class="num">Delayed (&gt;${slaLimit}d)</th>
            <th class="num">SLA %</th>
          </tr>
        </thead>
        <tbody>
          ${sortedWh
            .map((w) => {
              const avgD = w.orders > 0 ? w.fulfillSum / w.orders : 0;
              const slaPct = w.orders > 0 ? (w.onTime / w.orders) * 100 : 0;
              const volShare = rows.length > 0 ? (w.orders / rows.length) * 100 : 0;
              return `<tr>
                <td><strong>${w.name}</strong></td>
                <td class="num">${fmtInt(w.orders)}</td>
                <td class="num">${fmtPct(volShare, 1)}</td>
                <td class="num"><strong>${fmtCompact(w.rev)}</strong></td>
                <td class="num">${avgD.toFixed(2)} d</td>
                <td class="num" style="color:#059669;">${fmtInt(w.onTime)}</td>
                <td class="num" style="color:#e11d48;">${fmtInt(w.delayed)}</td>
                <td class="num"><span class="status-pill ${slaPct >= 52 ? "status-good" : "status-warn"}">${fmtPct(slaPct, 1)}</span></td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;

    // Fulfillment Days Histogram SVG
    const daysArr = Object.keys(dayHist).map(Number).sort((a, b) => a - b);
    const maxDayCount = Math.max(...Object.values(dayHist), 1);
    const W = 620, H = 175, padL = 40, padR = 15, padT = 18, padB = 32;
    const plotW = W - padL - padR;
    const plotH = H - padT - padB;
    const barW = plotW / daysArr.length - 6;

    const barsSvg = daysArr
      .map((d, i) => {
        const cnt = dayHist[d] || 0;
        const bh = (cnt / maxDayCount) * plotH;
        const bx = padL + i * (plotW / daysArr.length) + 3;
        const by = padT + plotH - bh;
        const isOk = d <= slaLimit;
        return `
          <rect x="${bx.toFixed(1)}" y="${by.toFixed(1)}" width="${barW.toFixed(1)}" height="${bh.toFixed(1)}" fill="${isOk ? "#0d9488" : "#e11d48"}" rx="2">
            <title>${d} Days Fulfillment: ${cnt} orders</title>
          </rect>
          <text x="${(bx + barW / 2).toFixed(1)}" y="${by - 4}" text-anchor="middle" font-size="9.5" fill="#475569">${cnt}</text>
          <text x="${(bx + barW / 2).toFixed(1)}" y="${H - 10}" text-anchor="middle" font-size="10" font-weight="600" fill="#334155">${d}d</text>
        `;
      })
      .join("");

    document.getElementById("fulfillmentHistogram").innerHTML = `
      <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:100%;">
        <line x1="${padL}" y1="${padT + plotH}" x2="${W - padR}" y2="${padT + plotH}" stroke="#cbd5e1" />
        ${barsSvg}
      </svg>`;

    // Regional GPS Bubble Plot (New Zealand Lat/Lng)
    const regList = Object.values(regStats).filter((r) => r.orders > 0);
    const maxRegRev = Math.max(...regList.map((r) => r.rev), 1);
    // NZ bounds: Lng ~167 to 179, Lat ~-47 to -34
    const minLng = 166.5, maxLng = 179.0;
    const minLat = -47.2, maxLat = -34.2;

    const mapW = 620, mapH = 250;
    const bubbles = regList
      .map((r) => {
        const cx = 40 + ((r.lng - minLng) / (maxLng - minLng)) * (mapW - 80);
        const cy = mapH - 25 - ((r.lat - minLat) / (maxLat - minLat)) * (mapH - 50);
        const rad = 3.5 + Math.sqrt(r.rev / maxRegRev) * 9;
        const avgF = r.fulfillSum / r.orders;
        const color = avgF <= slaLimit ? "#0d9488" : "#f59e0b";
        return `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${rad.toFixed(1)}" fill="${color}" fill-opacity="0.75" stroke="#0f172a" stroke-width="0.8">
          <title>${r.suburb}, ${r.city}: ${fmtCurrency(r.rev, 0)} (${r.orders} orders, Avg ${avgF.toFixed(1)}d)</title>
        </circle>`;
      })
      .join("");

    document.getElementById("regionalMapChart").innerHTML = `
      <svg viewBox="0 0 ${mapW} ${mapH}" style="width:100%;height:100%;background:#f0f9ff;border-radius:8px;border:1px solid #bae6fd;">
        <text x="14" y="20" font-size="11" font-weight="700" fill="#0369a1">New Zealand Delivery Locations (GPS Coordinate Projection)</text>
        <text x="14" y="35" font-size="10" fill="#0284c7">Bubble Size = Revenue ($) &bull; Teal = Avg Fulfillment &le;${slaLimit}d &bull; Amber = &gt;${slaLimit}d</text>
        ${bubbles}
      </svg>`;

    const sortedCities = Object.values(cityStats).sort((a, b) => b.rev - a.rev);
    document.getElementById("regionalTableContainer").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Delivery City</th>
            <th class="num">Orders</th>
            <th class="num">Units</th>
            <th class="num">Total Sales</th>
            <th class="num">Share %</th>
            <th class="num">Profit</th>
            <th class="num">Avg Fulfill</th>
          </tr>
        </thead>
        <tbody>
          ${sortedCities
            .map((c, idx) => {
              const share = totalRev > 0 ? (c.rev / totalRev) * 100 : 0;
              const avgF = c.orders > 0 ? c.fulfillSum / c.orders : 0;
              return `<tr>
                <td>#${idx + 1}</td>
                <td><strong>${c.city}</strong></td>
                <td class="num">${fmtInt(c.orders)}</td>
                <td class="num">${fmtInt(c.qty)}</td>
                <td class="num"><strong>${fmtCurrency(c.rev, 2)}</strong></td>
                <td class="num">${fmtPct(share)}</td>
                <td class="num" style="color:#059669;">${fmtCurrency(c.profit, 2)}</td>
                <td class="num">${avgF.toFixed(2)} d</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;
  }

  // TAB 5: Cost, Profitability & DAX
  function renderProfitabilityTab(rows, totalRev) {
    const prodProf = {};
    Object.entries(META.products).forEach(([idx, name]) => {
      prodProf[idx] = { idx: Number(idx), name, orders: 0, qty: 0, priceSum: 0, costSum: 0, rev: 0, cogs: 0, profit: 0 };
    });

    // Cost-to-Price ratio bands
    const bands = [
      { label: "High Margin (Cost 40%–50% of Price)", min: 0, max: 0.505, orders: 0, rev: 0, profit: 0 },
      { label: "Upper-Mid Margin (Cost 51%–60% of Price)", min: 0.505, max: 0.605, orders: 0, rev: 0, profit: 0 },
      { label: "Standard Margin (Cost 61%–70% of Price)", min: 0.605, max: 0.705, orders: 0, rev: 0, profit: 0 },
      { label: "Compressed Margin (Cost 71%–85% of Price)", min: 0.705, max: 1.0, orders: 0, rev: 0, profit: 0 }
    ];

    rows.forEach((r) => {
      const p = prodProf[r[8]];
      const qty = r[9];
      const uPrice = r[10];
      const uCost = r[11];
      const rev = r[12];
      const cogs = qty * uCost;
      const prof = rev - cogs;

      if (p) {
        p.orders += 1;
        p.qty += qty;
        p.priceSum += uPrice;
        p.costSum += uCost;
        p.rev += rev;
        p.cogs += cogs;
        p.profit += prof;
      }

      const ratio = uPrice > 0 ? uCost / uPrice : 0;
      for (const b of bands) {
        if (ratio >= b.min && ratio < b.max) {
          b.orders += 1;
          b.rev += rev;
          b.profit += prof;
          break;
        }
      }
    });

    const pList = Object.values(prodProf)
      .filter((p) => p.orders > 0)
      .sort((a, b) => b.profit / b.rev - a.profit / a.rev);

    document.getElementById("profitabilityTableContainer").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>Product</th>
            <th class="num">Avg Unit Price</th>
            <th class="num">Avg Unit Cost</th>
            <th class="num">Unit Margin ($)</th>
            <th class="num">Total Sales</th>
            <th class="num">Total COGS</th>
            <th class="num">Gross Profit</th>
            <th class="num">Margin %</th>
          </tr>
        </thead>
        <tbody>
          ${pList
            .map((p) => {
              const avgP = p.priceSum / p.orders;
              const avgC = p.costSum / p.orders;
              const mPct = (p.profit / p.rev) * 100;
              return `<tr>
                <td><strong>${p.name}</strong></td>
                <td class="num">${fmtCurrency(avgP, 2)}</td>
                <td class="num">${fmtCurrency(avgC, 2)}</td>
                <td class="num" style="color:#059669;">+${fmtCurrency(avgP - avgC, 2)}</td>
                <td class="num">${fmtCompact(p.rev)}</td>
                <td class="num">${fmtCompact(p.cogs)}</td>
                <td class="num"><strong>${fmtCompact(p.profit)}</strong></td>
                <td class="num"><span class="status-pill ${mPct >= 38 ? "status-good" : mPct >= 36 ? "status-warn" : "status-bad"}">${fmtPct(mPct)}</span></td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>`;

    const maxBandRev = Math.max(...bands.map((b) => b.rev), 1);
    document.getElementById("marginBandContainer").innerHTML = bands
      .map((b) => {
        const wPct = ((b.rev / maxBandRev) * 100).toFixed(1);
        const mPct = b.rev > 0 ? (b.profit / b.rev) * 100 : 0;
        return `
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;">
            <span><strong>${b.label}</strong> (${fmtInt(b.orders)} orders)</span>
            <span><strong>${fmtCompact(b.rev)}</strong> &bull; <span style="color:#059669;font-weight:600;">${fmtPct(mPct)} Avg Margin</span></span>
          </div>
          <div class="bar-track" style="height:16px;">
            <div class="bar-fill" style="width:${wPct}%;background:#0d9488;"></div>
          </div>
        </div>`;
      })
      .join("");

    renderOrderExplorer();
  }

  function renderOrderExplorer() {
    const q = (document.getElementById("orderSearchInput").value || "").trim().toLowerCase();
    const matched = filteredRows
      .filter((r) => {
        if (!q) return true;
        const ordNo = ("so - " + r[0]).toLowerCase();
        const custName = (META.customers[r[3]] || "").toLowerCase();
        return ordNo.includes(q) || custName.includes(q);
      })
      .slice(0, 100);

    document.getElementById("orderExplorerTable").innerHTML = `
      <table class="pbi-table">
        <thead>
          <tr>
            <th>OrderNumber</th>
            <th>OrderDate</th>
            <th>Ship Date</th>
            <th>Customer</th>
            <th>Channel</th>
            <th>Curr</th>
            <th>Whse</th>
            <th>Product</th>
            <th class="num">Qty</th>
            <th class="num">Unit Price</th>
            <th class="num">Unit Cost</th>
            <th class="num">Total Revenue</th>
          </tr>
        </thead>
        <tbody>
          ${matched
            .map(
              (r) => `<tr>
              <td><strong>SO - ${r[0]}</strong></td>
              <td>${r[1]}</td>
              <td>${r[2]}</td>
              <td>${META.customers[r[3]] || r[3]}</td>
              <td>${META.channels[r[4]]}</td>
              <td>${META.currencies[r[5]]}</td>
              <td>${META.warehouses[r[6]]}</td>
              <td>${META.products[r[8]]}</td>
              <td class="num">${r[9]}</td>
              <td class="num">${fmtCurrency(r[10], 2)}</td>
              <td class="num">${fmtCurrency(r[11], 2)}</td>
              <td class="num"><strong>${fmtCurrency(r[12], 2)}</strong></td>
            </tr>`
            )
            .join("")}
        </tbody>
      </table>`;
  }

  // Event Listeners
  [slicerYear, slicerChannel, slicerCurrency, slicerWarehouse, slicerCity, slicerProduct].forEach((el) =>
    el.addEventListener("change", updateDashboard)
  );

  document.getElementById("trendMetricSelect").addEventListener("change", updateDashboard);
  document.getElementById("slaSlider").addEventListener("input", updateDashboard);
  ["fxNZD", "fxUSD", "fxAUD", "fxEUR"].forEach((id) => {
    document.getElementById(id).addEventListener("input", updateDashboard);
  });

  document.getElementById("btnResetFx").addEventListener("click", () => {
    ["fxNZD", "fxUSD", "fxAUD", "fxEUR"].forEach((id) => {
      document.getElementById(id).value = "1.00";
    });
    updateDashboard();
  });

  document.getElementById("orderSearchInput").addEventListener("input", renderOrderExplorer);

  document.getElementById("btnResetSlicers").addEventListener("click", () => {
    slicerYear.value = "ALL";
    slicerChannel.value = "ALL";
    slicerCurrency.value = "ALL";
    slicerWarehouse.value = "ALL";
    slicerCity.value = "ALL";
    slicerProduct.value = "ALL";
    document.getElementById("orderSearchInput").value = "";
    updateDashboard();
  });

  // Page Tab switching
  document.querySelectorAll(".page-tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".page-tab").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      const target = document.getElementById(btn.getAttribute("data-tab"));
      if (target) target.classList.add("active");
    });
  });

  // Export Filtered CSV
  document.getElementById("btnExportCsv").addEventListener("click", () => {
    const headers = [
      "OrderNumber",
      "OrderDate",
      "Ship Date",
      "Customer Name",
      "Channel",
      "Currency Code",
      "Warehouse Code",
      "City",
      "Product Name",
      "Order Quantity",
      "Unit Price",
      "Total Unit Cost",
      "Total Revenue",
      "Fulfillment Days"
    ];
    const lines = [headers.join(",")];
    filteredRows.forEach((r) => {
      const reg = META.regions[r[7]] || {};
      lines.push(
        [
          `"SO - ${r[0]}"`,
          r[1],
          r[2],
          `"${(META.customers[r[3]] || "").replace(/"/g, '""')}"`,
          META.channels[r[4]],
          META.currencies[r[5]],
          META.warehouses[r[6]],
          `"${(reg.city || "").replace(/"/g, '""')}"`,
          `"${META.products[r[8]] || ""}"`,
          r[9],
          r[10],
          r[11],
          r[12],
          r[13]
        ].join(",")
      );
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Filtered_Sales_Orders_${filteredRows.length}_rows.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });

  // Initial load
  updateDashboard();
})();
